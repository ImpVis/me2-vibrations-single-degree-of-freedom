<template>
    <div>
        <iv-visualisation :title="projectName">
            <div style="margin:5vh;">
                <div id='graph'></div>
                
                <div style="margin:20px;" v-show="lightlyDamped">
                    <p style="font-size:14px" class="small">{{ solnText }}</p>
                    <h5>System Parameters:</h5>
                    <p style="font-size:14px" class="small">
                    Natural Frequency, ω<sub>n</sub> (rad/s): {{ wn }} rad/s
                    <br>
                    Natural Frequency, ω<sub>n</sub> (Hz): {{ wnHz }} Hz
                    <br>
                    Damped Natural Frequency, ω<sub>d</sub> (rad/s): {{ wd }} rad/s
                    <br>
                    Damped Natural Frequency, ω<sub>d</sub> (Hz): {{ wdHz }} Hz
                    <br>
                    Maximum displacement (m): {{ maxAmp }} m
                    </p>
                </div>

                <div style="margin:20px;" v-show="!lightlyDamped">
                    <p style="font-size:14px" class="small">{{ solnText }}</p>
                    <h5>System Parameters:</h5>
                    <p style="font-size:15px" class="small">
                    Natural Frequency, ω<sub>n</sub> (rad/s): {{ wn }} rad/s
                    <br>
                    Natural Frequency, ω<sub>n</sub> (Hz): {{ wnHz }} Hz
                    <br>
                    Maximum displacement (m): {{ maxAmp }} m
                    </p>
                </div>
            </div>

            <template #hotspots>
                <iv-pane position="left">
                    <iv-sidebar-content style="font-size:12px" nextText="Forced" previousText="2DOF">
                        <iv-sidebar-section title="SDOF">
                            <img src="./assets/SDOF_Pic.png" class="centre" style="width:9vw;">
                            <p style="font-size:14px" class="small">A SDOF system can be used to model simple vibrating systems. It consists of a point mass attached to a massless spring that is grounded on the other end, constrained to move only in the direction perpendicular to the ground. Energy dissipation may be represented by a massless viscous damper, that produces a drag force opposing the motion of the mass.</p>
                            <img src="./assets/EoM.png" style="width:17vw;">
                            <!-- This SDOF solver takes in your parameters and then produces a time history plot of your system. Try it out by changing the input parameters and looking at how the solution changes. To submit feedback for this module please click <a href="https://forms.gle/puL3mKPbchXzsRrV7" target="_blank">here</a>. -->
                            <!-- <iv-equation-box equation='f({x}) = \int_{-\infty}^\infty\hat f(\xi)\,e^{2 \pi i \xi x}\,d\xi' :stylise=false> </iv-equation-box> -->
                            <p style="font-size:14px" class="small">Observe the displacement, velocity, and acceleration response of the SDOF system by inputting parameters for mass, spring constant, damping coefficient/ratio and initial displacement.</p>
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <iv-pane position="right" :allowResize="false">
                    <div style="margin-top:0px; padding:20px;" >
                        <h5>Desired Plots</h5>
                        <form>
                            <p style="font-size:15px" class="small"><input type="radio" id="plot1" value="1" v-model="displaysplot" checked>
                            <label for="plot1">Displacement</label>
                            <br>
                            <input type="radio" id="plot2" value="2" v-model="displaysplot">
                            <label for="plot2">+ Velocity</label>
                            <br>
                            <input type="radio" id="plot3" value="3" v-model="displaysplot">
                            <label for="plot3">+ Acceleration</label></p>
                            
                        </form>
                        <h5>System Parameters</h5>
                        <p style="font-size:15px" class="big"><label>Mass, m (kg)</label>
                        <br>
                        <input v-model="mass" @change="update">
                        <br>
                        <label>Spring Constant, k (N/m)</label>
                        <br>
                        <input v-model="springConst"  @change="update">
                        <br>
                        <label>Use Damping Coefficient</label>
                        <br>
                        <iv-toggle-basic @input="dampToggle"></iv-toggle-basic>
                        <label v-show="!showCoeff" >Damping Ratio, ζ</label>
                        <label v-show="showCoeff">Damping Coefficient, c (Ns/m)</label>
                        <br>
                        <input v-model="dampRatio"  @change="updateDampRatio" v-show="!showCoeff">
                        
                        
                        
                        <input v-model="dampCoeff"  @change="updateDampCoeff"  v-show="showCoeff">
                        </p>

                        <h5>Initial Conditions</h5>
                        <p style="font-size:15px" class="small"><label>Initial Displacement, X0 (m)</label>
                        <br>
                        <input v-model="initDisp"  @change="update">
                        <br></p>
                        
                        <h5>Computational Parameters</h5>
                        <p style="font-size:15px" class="small"><label>Time Span, t (s)</label>
                        <br>
                        <input v-model="timeSpan"  @change="update">
                        <br>
                        <label>Number of Points</label>
                        <br>
                        <input v-model="numPoints" @change="update"></p>
                        <br>
                    </div>
                </iv-pane>
                
                <!-- <iv-fixed-hotspot position="topright" style="width:300px; z-index:2" transparent>
                    
                </iv-fixed-hotspot> -->
            </template>

        
        </iv-visualisation>
    </div>
</template>
<script>
import Plotly from 'plotly.js/dist/plotly.min.js'; // eslint-disable-line no-unused-vars

export default {
    name:"App",
    data(){
        return {
            projectName: 'Vibrations App - SDOF',
            mass: 1,
            dampRatio: 0.1,
            initDisp:0.1,
            timeSpan:2,
            springConst: 1000,
            dampCoeff:6.325,
            numPoints:1000,
            updatePlot: true,
            wn: 32,
            wnHz: 5,
            wd: 31,
            wdHz: 5,
            maxAmp: 0.1,
            solnText: "This is an Under Damped Solution",
            showText: true,
            showCoeff: false,
            lightlyDamped: true,
            displaysplot: "1",
        }
    },
    methods: {
        update(){
            console.log('mass = ', this.mass);
            if(this.mass <= 0){
                this.mass = 1;
                window.alert("Mass must be greater than 0.");
            }
            else if(this.springConst <= 0){
                window.alert("Spring constant must be greater than 0.");
                this.springConst = 1000;
            }
            else if(this.timeSpan <= 0){
                window.alert("Time span must be greater than 0.");
                this.springConst = 1000;
            }
            else if(this.numPoints <= (2*this.wnHz * this.timeSpan)){
                window.alert(`Please ensure your sampling frequency (Number of Points/Time Span), ${this.numPoints/this.timeSpan} Hz, is well above double the natural frequency of the system, ${this.wnHz} Hz. This is to prevent aliasing from occuring. We recommend increasing the number of points beyond ${4*this.wnHz * this.timeSpan} points.`);
                this.numPoints = (4*this.wnHz * this.timeSpan);
            }
            else{
                this.updatePlot = true;
            }

            
        },
        updateDampCoeff(){
            if(this.dampCoeff < 0){
                window.alert("Damping coefficient must be greater than 0.");
                this.dampCoeff = 6.325;
            }
            this.dampRatio = Math.round( (this.dampCoeff / (2*Math.sqrt(this.springConst * this.mass))) *1000 )/1000;
            this.updatePlot = true;
        },
        updateDampRatio(){
            if(this.dampRatio < 0 || this.dampRatio > 2){
                window.alert("Damping ratio must be greater than 0 and less than or equal to 2.");
                this.dampRatio = 0.1;
            }
            this.dampCoeff = Math.round( (this.dampRatio *2 * Math.sqrt(this.springConst * this.mass) )*1000)/1000;
            this.updatePlot = true;
        },
        dampToggle(){
            this.showCoeff = !this.showCoeff;
        },
    },
    mounted(){
        let vm = this; // eslint-disable-line no-unused-vars

        let layout = {
            title: "Time History Plot of Solution",
            xaxis: {title:"Time (sec)"},
          yaxis: {title:"Displacement, x (m)"},
          font: {
                color: "#003E74",
                weight: 900
          }
        };

        let layout2 = {
            title: "Time History Plot of Solution",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x (m)"},
            yaxis2: {title:"Velocity, v (m/s)", overlaying: 'y', side: 'right'},
            font: {
                color: "#003E74",
                weight: 900
            },
            showlegend: true,
            legend: {
                orientation: 'v',
                xanchor: "centre",
                x: 0,
                y: -0.3,
            }
        };

        let layout3 = {
            title: "Time History Plot of Solution",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x (m)"},
            yaxis2: {title:"Acceleration, a (m/s<sup>n</sup>)", overlaying: 'y', side: 'right'},
            font: {
                color: "#003E74",
                weight: 900
            },
            showlegend: true,
            legend: {
                orientation: 'v',
                xanchor: "centre",
                x: 0,
                y: -0.3,
            }
        };

        let config = {responsive: true};

        function SDOF_solver(){
            
            let m = vm.mass;
            let k = vm.springConst;
            let dampRatio = Number(vm.dampRatio);
            let x0 = vm.initDisp;
            let tend = vm.timeSpan;
            let n = vm.numPoints;
            let x = [];
            let vel = [];
            let A, B;
            let d = vm.displaysplot

            let wn = Math.sqrt(k / m);  // Natural Freq of spring mass system
            let wnHz = wn/(2*Math.PI);    // Natural freq in Hz
            let wd, wdHz;
            if (0 < dampRatio && dampRatio < 1){
                wd = wn*Math.sqrt(1 - dampRatio**2);    // Damped nat freq (rad/s)
                wdHz = wd/(2*Math.PI);     // Damped Natural freq in Hz
            } else{
                wd = 0;
                wdHz = 0;
            }

            let t = [];
            for(let i = 0; i < tend; i = i+ (tend/n)){
                t.push(i);
            }


            if (dampRatio == 0){
                for(let i = 0; i < t.length; i++){
                    x.push(x0 * Math.cos(wn * t[i])); 
                    vel.push(x0 * Math.cos(wn * (t[i] + (Math.PI/(2*wn)))));
                }
                vm.solnText = "This is an Undamped Solution";
                vm.lightlyDamped = false;
            }
            else if(dampRatio < 1 && dampRatio > 0){
                vm.solnText = "This is an Under Damped Solution";
                vm.lightlyDamped = true;
                wd = wn * Math.sqrt(1 - dampRatio ** 2);
                A = x0;
                B = dampRatio * A / wd;

                for(let i = 0; i < t.length; i++){
                   x.push(Math.exp(-dampRatio * wn * t[i]) * (A * Math.cos(wd * t[i]) + B * Math.sin(wd * t[i])));
                   vel.push(Math.exp(-dampRatio * wn * (t[i] + (Math.PI/(2*wn)))) * (A * Math.cos(wd * (t[i] + (Math.PI/(2*wn)))) + B * Math.sin(wd * t[i])));  
                }
            }
            else if( dampRatio == 1){
                vm.solnText = "This is a Critically Damped Solution";
                vm.lightlyDamped = false;
                A = x0;
                B = A * wn;

                for(let i = 0; i < t.length; i++){
                   x.push((A + B * t[i]) * Math.exp(-wn * t[i]));
                   vel.push((A + B * (t[i] + (Math.PI/(2*wn)))) * Math.exp(-wn * (t[i] + (Math.PI/(2*wn)))));

                }
            }
            else if( dampRatio > 1){
                vm.solnText = "This is an Over Damped Solution";
                vm.lightlyDamped = false;
                
                A = x0 * (dampRatio + Math.sqrt(dampRatio ** 2 - 1)) / (2 * Math.sqrt(dampRatio ** 2 - 1));
                B = x0 - A;

                for(let i = 0; i < t.length; i++){
                    x.push(A * Math.exp((-dampRatio + Math.sqrt(dampRatio ** 2 - 1)) * wn * t[i]) + B * Math.exp(
                    (-dampRatio - Math.sqrt(dampRatio ** 2 - 1)) * wn * t[i]));
                    vel.push(A * Math.exp((-dampRatio + Math.sqrt(dampRatio ** 2 - 1)) * wn * (t[i] + (Math.PI/(2*wn)))) + B * Math.exp(
                    (-dampRatio - Math.sqrt(dampRatio ** 2 - 1)) * wn * (t[i] + (Math.PI/(2*wn))))); 
                }
            } else{
                vm.solnText = "This is an unaccounted for Solution";
                vm.lightlyDamped = false;
            }

            let acc = [];
            for(let i = 0; i < t.length; i++){
                vel[i] = vel[i] * wd
                acc[i] = - x[i] * wd**2
            }

            let max = x.reduce(function(a,b) {
                return Math.max(a,b)
            });
            vm.maxAmp = Math.round(max*100)/100;
            vm.wn = Math.round(wn*100)/100;
            vm.wnHz = Math.round(wnHz*100)/100;
            vm.wd =  Math.round(wd * 100)/100;
            vm.wdHz = Math.round(wdHz * 100)/100;

            return [d, t, x, vel, acc]
        }

        //let config = {responsive: true};

        let i = 0;
        function update(){
            requestAnimationFrame(update);
            
            if(vm.updatePlot || i > 30){
                vm.updatePlot = false;
                
                let data = SDOF_solver();
                
                let absx = [];
                let absv = [];
                let absa = [];
                for (let i = 0; i < data[1].length; i++) {
                    absx.push(Math.abs(data[2][i]));
                    absv.push(Math.abs(data[3][i]));
                    absa.push(Math.abs(data[4][i]));
                }
                let maxx = absx.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxv = absv.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);
                let maxa = absa.reduce(function(a, b) {
                    return Math.max(a, b);
                }, -Infinity);

                layout2 = {
                    title: "Time History Plot of Solution",
                    xaxis: {title:"Time (sec)"},
                    yaxis: {
                        title:"Displacement, x (m)", 
                        range: [(-1)*maxx, maxx]
                        },
                    yaxis2: {
                        title:"Velocity, x&#775; (m/s)", 
                        overlaying: 'y', 
                        side: 'right', 
                        range: [(-1)*maxv, maxv]
                        },
                    font: {
                        color: "#003E74",
                        weight: 900
                    },
                    showlegend: true,
                    legend: {
                        orientation: 'v',
                        xanchor: "centre",
                        x: 0,
                        y: -0.3,
                    }
                };

                layout3 = {
                    title: "Time History Plot of Solution",
                    xaxis: {title:"Time (sec)"},
                    yaxis: {
                        title:"Displacement, x (m)", 
                        range: [(-1)*maxx, maxx]
                    },
                    yaxis2: {
                        title:"Acceleration, &#7821; (m/s<sup>2</sup>)", 
                        overlaying: 'y', 
                        side: 'right', 
                        range: [(-1)*maxa, maxa],
                        showgrid: false,
                    },
                    font: {
                        color: "#003E74",
                        weight: 900
                    },
                    showlegend: true,
                    legend: {
                        orientation: 'v',
                        xanchor: "centre",
                        x: 0,
                        y: -0.3,
                    }
                };

                if (data[0] == "1"){
                    Plotly.newPlot('graph', [{
                    x : data[1],
                    y : data[2],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout,
                    config
                    )
                }

                /* if (data[0] == "2"){
                    Plotly.newPlot('graph', [{
                    x : data[1],
                    y : data[2],
                    xaxis: 'x1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    name: "Displacement",
                    mode: 'lines'
                    },
                    {
                        x: data[1],
                        y: data[3],
                        xaxis: 'x1',
                        yaxis2: 'y2', 
                        line: {simplify: false},
                        name: "Velocity",
                        mode: 'lines'
                    }],
                    layout3,
                    config
                    )
                } */
                
                if (data[0] == "2"){
                    Plotly.newPlot('graph', [{
                    x : data[1],
                    y : data[2],
                    xaxis: 'x1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    name: "Displacement",
                    mode: 'lines'
                    },
                    {
                    x: data[1],
                    y: data[3],
                    xaxis: 'x1',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    name: "Velocity",
                    mode: 'lines'
                    }],
                    layout2,
                    config
                    )
                }

                if (data[0] == "3"){
                    Plotly.newPlot('graph', [{
                    x : data[1],
                    y : data[2],
                    xaxis: 'x1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    name: "Displacement",
                    mode: 'lines'
                    },
                    {
                    x: data[1],
                    y: data[4],
                    xaxis: 'x1',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(101,201,104)'},
                    name: "Acceleration",
                    mode: 'lines'
                    }],
                    layout3,
                    config
                    )
                }
                console.log(Math.max(absx))
                i=0;
                
            }

            i++
        }

        update();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
html{
    overflow: hidden;
}
.iv-pane-right{
    overflow: auto;
}
p.small {
  line-height: 1.5;
}
p.big {
  line-height: 1.5;
}
h5 {
  line-height: 10px;
}
img.centre {
  display: block;
  margin-left: auto;
  margin-right: auto;
}

#graph {
    z-index:-2;
}
@media screen and (orientation: portrait) {
    #graph {
        width:400px;
    }
}

@media screen and (orientation: landscape) {
    #graph {
        width:90%; height:400px;
    }
}
</style>